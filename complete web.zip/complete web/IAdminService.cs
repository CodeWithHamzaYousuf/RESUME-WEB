using WebApplication7.Models;

namespace WebApplication7.Services
{
    public interface IAdminService
    {
        Task<AdminUser?> AuthenticateAsync(string username, string password);
        Task<AdminUser?> GetAdminByIdAsync(int id);
        Task<AdminUser?> GetAdminByUsernameAsync(string username);
        Task<bool> UpdateLastLoginAsync(int adminId);
        string HashPassword(string password);
        bool VerifyPassword(string password, string hashedPassword);
    }
}

