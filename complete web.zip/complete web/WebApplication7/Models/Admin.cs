﻿namespace WebApplication7.Models
{
    public class Admin
    {
        public int Id { get; set; }               // ✅ Add this line if missing
        public string Username { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }
    }
}
