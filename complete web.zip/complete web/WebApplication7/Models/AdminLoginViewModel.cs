﻿namespace WebApplication7.Models
{
    public class AdminLoginViewModel
    {
        public string Username { get; set; }

        public string Password { get; set; }

        public bool RememberMe { get; set; } // ✅ This is the missing property
    }
}
