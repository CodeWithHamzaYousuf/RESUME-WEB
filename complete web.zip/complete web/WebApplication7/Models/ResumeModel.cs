using System.ComponentModel.DataAnnotations;

namespace WebApplication7.Models
{
    public class ResumeModel
    {
        // Personal Information
        [Required]
        public string FullName { get; set; } = string.Empty;
        
        [Required]
        [EmailAddress]
        public string Email { get; set; } = string.Empty;
        
        [Required]
        public string Phone { get; set; } = string.Empty;
        
        public string Address { get; set; } = string.Empty;
        public string LinkedIn { get; set; } = string.Empty;
        public string Website { get; set; } = string.Empty;
        
        // Professional Summary
        public string ProfessionalSummary { get; set; } = string.Empty;
        
        // Work Experience
        public List<WorkExperience> WorkExperiences { get; set; } = new List<WorkExperience>();
        
        // Education
        public List<Education> Educations { get; set; } = new List<Education>();
        
        // Skills
        public List<string> Skills { get; set; } = new List<string>();
        
        // Projects
        public List<Project> Projects { get; set; } = new List<Project>();
        
        // Certifications
        public List<Certification> Certifications { get; set; } = new List<Certification>();
        
        // Languages
        public List<Language> Languages { get; set; } = new List<Language>();
    }

    public class WorkExperience
    {
        public string JobTitle { get; set; } = string.Empty;
        public string Company { get; set; } = string.Empty;
        public string Location { get; set; } = string.Empty;
        public string StartDate { get; set; } = string.Empty;
        public string EndDate { get; set; } = string.Empty;
        public bool IsCurrentJob { get; set; }
        public List<string> Responsibilities { get; set; } = new List<string>();
    }

    public class Education
    {
        public string Degree { get; set; } = string.Empty;
        public string Institution { get; set; } = string.Empty;
        public string Location { get; set; } = string.Empty;
        public string GraduationYear { get; set; } = string.Empty;
        public string GPA { get; set; } = string.Empty;
    }

    public class Project
    {
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string Technologies { get; set; } = string.Empty;
        public string Link { get; set; } = string.Empty;
    }

    public class Certification
    {
        public string Name { get; set; } = string.Empty;
        public string IssuingOrganization { get; set; } = string.Empty;
        public string IssueDate { get; set; } = string.Empty;
        public string ExpiryDate { get; set; } = string.Empty;
    }

    public class Language
    {
        public string Name { get; set; } = string.Empty;
        public string Proficiency { get; set; } = string.Empty;
    }
}

