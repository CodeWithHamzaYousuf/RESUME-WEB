using WebApplication7.Models;
using System.Text.Json;

namespace WebApplication7.Services
{
    public class AdminService : IAdminService
    {
        private readonly string _jsonPath = "admin.json"; // or "Data/admin.json"

        public async Task<Admin?> AuthenticateAsync(string username, string password)
        {
            if (!File.Exists(_jsonPath)) return null;

            var json = await File.ReadAllTextAsync(_jsonPath);
            var admins = JsonSerializer.Deserialize<List<Admin>>(json);

            return admins?.FirstOrDefault(a =>
                a.Username == username && a.Password == password);
        }
    }
}
