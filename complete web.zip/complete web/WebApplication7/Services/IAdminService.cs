using WebApplication7.Models;
using System.Threading.Tasks;

namespace WebApplication7.Services
{
    public interface IAdminService
    {
        Task<Admin?> AuthenticateAsync(string username, string password);
    }
}
