﻿using Microsoft.AspNetCore.Mvc;
using WebApplication7.Models;
using WebApplication7.Services;
using Microsoft.AspNetCore.Http;

namespace WebApplication7.Controllers
{
    public class AdminController : Controller
    {
        private readonly IAdminService _adminService;

        public AdminController(IAdminService adminService)
        {
            _adminService = adminService;
        }

        // ✅ GET: /Admin/Login
        [HttpGet]
        public IActionResult Login()
        {
            if (IsAdminLoggedIn())
                return RedirectToAction("Dashboard");

            return View();
        }

        // ✅ POST: /Admin/Login
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(AdminLoginViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            var admin = await _adminService.AuthenticateAsync(model.Username, model.Password);

            if (admin != null)
            {
                // ✅ Store in session
                HttpContext.Session.SetInt32("AdminId", admin.Id);
                HttpContext.Session.SetString("AdminUsername", admin.Username);
                HttpContext.Session.SetString("AdminRole", admin.Role);

                // Optional: implement remember me logic using cookies
                if (model.RememberMe)
                {
                    Response.Cookies.Append("RememberAdmin", admin.Username, new CookieOptions
                    {
                        Expires = DateTimeOffset.UtcNow.AddDays(7)
                    });
                }

                return RedirectToAction("Dashboard");
            }

            ModelState.AddModelError("", "Invalid username or password.");
            return View(model);
        }

        // ✅ GET: /Admin/Dashboard
        public IActionResult Dashboard()
        {
            if (!IsAdminLoggedIn())
                return RedirectToAction("Login");

            ViewBag.AdminUsername = HttpContext.Session.GetString("AdminUsername");
            return View();
        }

        // ✅ GET: /Admin/Users
        public IActionResult Users()
        {
            if (!IsAdminLoggedIn())
                return RedirectToAction("Login");

            return View();
        }

        // ✅ GET: /Admin/Jobs
        public IActionResult Jobs()
        {
            if (!IsAdminLoggedIn())
                return RedirectToAction("Login");

            return View();
        }

        // ✅ GET: /Admin/Mentors
        public IActionResult Mentors()
        {
            if (!IsAdminLoggedIn())
                return RedirectToAction("Login");

            return View();
        }

        // ✅ GET: /Admin/Assessments
        public IActionResult Assessments()
        {
            if (!IsAdminLoggedIn())
                return RedirectToAction("Login");

            return View();
        }

        // ✅ GET: /Admin/Messages
        public IActionResult Messages()
        {
            if (!IsAdminLoggedIn())
                return RedirectToAction("Login");

            return View();
        }

        // ✅ GET: /Admin/Settings
        public IActionResult Settings()
        {
            if (!IsAdminLoggedIn())
                return RedirectToAction("Login");

            return View();
        }

        // ✅ Admin logout
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            Response.Cookies.Delete("RememberAdmin");

            return RedirectToAction("Login");
        }

        // ✅ Helper: check session
        private bool IsAdminLoggedIn()
        {
            return HttpContext.Session.GetInt32("AdminId").HasValue;
        }
    }
}
