﻿using Microsoft.AspNetCore.Mvc;
using WebApplication7.Models;
using WebApplication7.Services;
using System.Text.Json;
using System.IO;

namespace WebApplication7.Controllers
{
    public class LoginController : Controller
    {
        private readonly UserService _userService;

        public LoginController()
        {
            _userService = new UserService();
        }

        // GET: /Login
        public IActionResult Index()
        {
            return View();
        }

        // POST: /Login
        [HttpPost]
        public IActionResult Index(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                // 🔸 1. Check if it's an admin user from JSON file
                var adminUsers = LoadAdminUsers();
                var isAdmin = adminUsers.FirstOrDefault(a =>
                    a.Username == model.Username && a.Password == model.Password);

                if (isAdmin != null)
                {
                    HttpContext.Session.SetString("Username", isAdmin.Username);
                    HttpContext.Session.SetString("Role", "Admin");

                    return RedirectToAction("Dashboard", "Admin");
                }

                // 🔸 2. Regular user login from service
                var user = _userService.ValidateUser(model);
                if (user != null)
                {
                    HttpContext.Session.SetString("Username", user.Username);
                    HttpContext.Session.SetInt32("UserId", user.Id);

                    return RedirectToAction("Index", "Home");
                }

                // ❌ Invalid login
                ModelState.AddModelError("", "Invalid username or password");
            }

            return View(model);
        }

        // GET: /Signup
        public IActionResult Signup()
        {
            return View();
        }

        // POST: /Signup
        [HttpPost]
        public IActionResult Signup(SignupViewModel model)
        {
            if (ModelState.IsValid)
            {
                if (_userService.RegisterUser(model))
                {
                    TempData["SuccessMessage"] = "Registration successful! Please login.";
                    return RedirectToAction("Index");
                }
                else
                {
                    ModelState.AddModelError("", "Username or email already exists");
                }
            }
            return View(model);
        }

        // GET: /Logout
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index");
        }

        // 🔹 Helper method to load admin.json
        private List<Admin> LoadAdminUsers()
        {
            var filePath = "admin.json"; // or "Data/admin.json" if you placed it in a folder

            if (!System.IO.File.Exists(filePath))
                return new List<Admin>();

            var json = System.IO.File.ReadAllText(filePath);
            return JsonSerializer.Deserialize<List<Admin>>(json) ?? new List<Admin>();
        }
    }
}
