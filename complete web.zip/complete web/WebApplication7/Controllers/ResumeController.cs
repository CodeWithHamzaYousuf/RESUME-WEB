using Microsoft.AspNetCore.Mvc;
using WebApplication7.Models;
using System.Text.Json;

namespace WebApplication7.Controllers
{
    public class ResumeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Builder()
        {
            return View();
        }

        [HttpPost]
        public IActionResult GenerateResume([FromBody] ResumeModel resume)
        {
            if (resume == null)
            {
                return BadRequest("Resume data is required");
            }

            // Store resume data in session for preview
            HttpContext.Session.SetString("ResumeData", JsonSerializer.Serialize(resume));
            
            return Json(new { success = true, message = "Resume generated successfully" });
        }

        public IActionResult Preview()
        {
            var resumeDataJson = HttpContext.Session.GetString("ResumeData");
            if (string.IsNullOrEmpty(resumeDataJson))
            {
                return RedirectToAction("Builder");
            }

            var resumeData = JsonSerializer.Deserialize<ResumeModel>(resumeDataJson);
            return View(resumeData);
        }

        public IActionResult Download()
        {
            var resumeDataJson = HttpContext.Session.GetString("ResumeData");
            if (string.IsNullOrEmpty(resumeDataJson))
            {
                return RedirectToAction("Builder");
            }

            var resumeData = JsonSerializer.Deserialize<ResumeModel>(resumeDataJson);
            return View(resumeData);
        }
    }
}

