﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication7.Controllers
{
    public class Programs : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult BSSE()
        {
            return View();
        }

        public IActionResult BSCS()
        {
            return View();
        }
        public IActionResult BBA()
        {
            return View();
        }

        public IActionResult BSME()
        {
            return View();
        }

        public IActionResult BSFD()
        {
            return View();
        }
        public IActionResult MBBS()
        {
            return View();
        }
    }
}
